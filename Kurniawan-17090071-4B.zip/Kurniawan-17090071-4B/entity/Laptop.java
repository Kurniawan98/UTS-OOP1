package entity;

public class Laptop {

    private String nama;
    private String id;
    private String merk;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public Laptop(String id, String nama, String merk) {
        this.nama = nama;
        this.id = id;
        this.merk = merk;
    }


    public boolean equals(Object object) {
        Laptop temp = (Laptop) object;
        return id.equals(temp.getId());
    }

}